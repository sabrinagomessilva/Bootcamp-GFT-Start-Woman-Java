# Introdução ao Git e ao GitHub

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled.png)

Críticas: o que é um terminal? Como abrir? Outros programas: git bash

ver pastas: ls

voltar para pastas cd ..

criar pasta: mkdir nomePasta

ir para a pasta = cd nomePasta

echo hello > hello.txt  = *(criará aquivo hello.txt dentro da pasta nomePasta*

ls = (para vc ver o arquivo

deletar a pasta que criamos: del nomePasta (del não funciona no gitbash)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%201.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%202.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%203.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%204.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%205.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%206.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%207.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%208.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%209.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2010.png)

`ssh-keygen -t ed25519 -C "*your_email@example.com*"`

id_ed25519 id_ed25519.pub

> Enter passphrase (empty for no passphrase): [Type a passphrase]
Enter same passphrase again: [Type passphrase again]
> 

Chava pública e privida (id)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2011.png)

ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJs44+hxvC8ZxMAQyz+lCbR7y0PQsoT07Co5lPGftXc8 [sabrinagomes3@gmail.com](mailto:sabrinagomes3@gmail.com)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2012.png)

$ eval $(ssh-agent -s)
Agent pid 2203

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2013.png)

Outra forma de acesso pessoal 

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2014.png)

Meu Token: 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

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2015.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2016.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2017.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2018.png)

![Untitled](Introduc%CC%A7a%CC%83o%20ao%20Git%20e%20ao%20GitHub%2004be3ad6a0af434ba5f9e10b07d55969/Untitled%2019.png)