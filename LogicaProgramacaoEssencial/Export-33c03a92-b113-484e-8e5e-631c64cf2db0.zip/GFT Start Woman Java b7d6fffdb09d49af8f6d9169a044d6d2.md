# GFT Start Woman Java

Você tem até o dia **31/05/2022**
 para finalizar o bootcamp GFT Start Woman Java.

### Cuidado, Compromisso, Colaboração, Coragem,Criatividade

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled.png)

<aside>
👉 ~~Até  dia 26/04 para se inscrever~~
Até o dia 31/05 para terminar

</aside>

1. hard skills
2. Habilidades comportamentais (5 c´s e participação)
3. Saiba tudo sobre a empresa (site [aqui](https://www.gft.com/br/pt/about-us))
4. Soft skills é o mais necessário
5. Organize o tempo, não deixar pra última hora
6. Soft skills e hard skills

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%201.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%202.png)

Abstração de problemas

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%203.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%204.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%205.png)

• **Média**    Essa é a média aritmética e é calculada adicionando um grupo de números e dividindo pela contagem desses números. Por exemplo, a média de 2, 3, 3, 5, 7 e 10 é 30 dividido por 6, que é 5.

Então temos: 4 notas que somam: 5+7+10+3 = 25 

25/4 = 5,5

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%206.png)

NumeroAlunos = 4

Nota1, Nota2, Nota3, Nota4

SomaNota = Nota1+Nota2+Nota3+Nota4

Média = SomaNota / número de alunos 

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%207.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%208.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%209.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2010.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2011.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2012.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2013.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2014.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2015.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2016.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2017.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2018.png)

Exercício: Fluxograma: Calcula média e soma notas

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2019.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2020.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2021.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2022.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2023.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2024.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2025.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2026.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2027.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2028.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2029.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2030.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2031.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2032.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2033.png)

### Exercício:

declarar 4 variáveis: jan, fev, mar, abr

valor delas será o valor de venda do vendedor no mês respectivo

outra variável média dos valores

Se media maior = 5 mil = parabéns, você receberá abono de 10%

senão = você receberá 3% de abono

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2034.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2035.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2036.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2037.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2038.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2039.png)

Exercício: 

Pedir valor de 4 notas. Pedir nome do aluno. Exibir média. Exibir se aprovado

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2040.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2041.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2042.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2043.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2044.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2045.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2046.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2047.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2048.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2049.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2050.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2051.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2052.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2053.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2054.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2055.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2056.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2057.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2058.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2059.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2060.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2061.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2062.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2063.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2064.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2065.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2066.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2067.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2068.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2069.png)

![Untitled](GFT%20Start%20Woman%20Java%20b7d6fffdb09d49af8f6d9169a044d6d2/Untitled%2070.png)